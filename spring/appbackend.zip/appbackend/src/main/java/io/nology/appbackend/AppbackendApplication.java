package io.nology.appbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppbackendApplication.class, args);
	}

}
